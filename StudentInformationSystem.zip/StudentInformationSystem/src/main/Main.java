package main;
import dao.SISDAOInterface;
import dao.SISDAOImpl;
import model.Student;
import model.Teacher;
import model.Course;
import exception.*;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        SISDAOInterface dao = new SISDAOImpl();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("========== Student Information System ==========");
            System.out.println("1. Enroll Student in Course");
            System.out.println("2. Assign Teacher to Course");
            System.out.println("3. Record Payment");
            System.out.println("4. View Student Enrollments");
            System.out.println("5. View Teacher Courses");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline left by nextInt()

            switch (choice) {
                case 1: // Enroll Student in Course
                    System.out.print("Enter Student ID: ");
                    String studentId = scanner.nextLine();
                    System.out.print("Enter Course ID: ");
                    String courseId = scanner.nextLine();
                    System.out.print("Enter Enrollment Date (yyyy-mm-dd): ");
                    String enrollmentDate = scanner.nextLine();

                    try {
                        dao.enrollStudentInCourse(studentId, courseId, enrollmentDate);
                        System.out.println("[✓ SUCCESS] Student enrolled successfully!");
                    } catch (StudentNotFoundException | CourseNotFoundException | DuplicateEnrollmentException | InvalidEnrollmentDataException e) {
                        System.out.println("[✗ ERROR] " + e.getMessage());
                    }
                    break;

                case 2: // Assign Teacher to Course
                    System.out.print("Enter Course ID: ");
                    String courseIdToAssign = scanner.nextLine();
                    System.out.print("Enter Teacher ID: ");
                    String teacherId = scanner.nextLine();

                    try {
                        dao.assignTeacherToCourse(courseIdToAssign, teacherId);
                        System.out.println("[✓ SUCCESS] Teacher assigned to course successfully!");
                    } catch (TeacherNotFoundException | CourseNotFoundException e) {
                        System.out.println("[✗ ERROR] " + e.getMessage());
                    }
                    break;

                case 3: 
                    System.out.print("Enter Student ID: ");
                    String studentIdForPayment = scanner.nextLine();
                    System.out.print("Enter Amount: ");
                    double amount = scanner.nextDouble();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter Payment Date (yyyy-mm-dd): ");
                    String paymentDate = scanner.nextLine();

                    try {
                        dao.recordPayment(studentIdForPayment, amount, paymentDate);
                        System.out.println("[✓ SUCCESS] Payment recorded successfully!");
                    } catch (StudentNotFoundException | PaymentValidationException e) {
                        System.out.println("[✗ ERROR] " + e.getMessage());
                    }
                    break;

                case 4: 
                    System.out.print("Enter Student ID: ");
                    String studentIdForEnrollments = scanner.nextLine();

                    try {
                        List<String> enrollments = dao.getEnrollmentsForStudent(studentIdForEnrollments);
                        if (enrollments.isEmpty()) {
                            System.out.println("No enrollments found for Student ID: " + studentIdForEnrollments);
                        } else {
                            System.out.println("Enrollments for Student ID: " + studentIdForEnrollments);
                            for (String enrollment : enrollments) {
                                System.out.println(enrollment);
                            }
                        }
                    } catch (StudentNotFoundException e) {
                        System.out.println("[✗ ERROR] " + e.getMessage());
                    }
                    break;

                case 5: 
                    System.out.print("Enter Teacher ID: ");
                    String teacherIdForCourses = scanner.nextLine();

                    try {
                        List<String> coursesForTeacher = dao.getCoursesForTeacher(teacherIdForCourses);
                        if (coursesForTeacher.isEmpty()) {
                            System.out.println("No courses found for Teacher ID: " + teacherIdForCourses);
                        } else {
                            System.out.println("Courses for Teacher ID: " + teacherIdForCourses);
                            for (String course : coursesForTeacher) {
                                System.out.println(course);
                            }
                        }
                    } catch (TeacherNotFoundException e) {
                        System.out.println("[✗ ERROR] " + e.getMessage());
                    }
                    break;

                case 6: // Exit
                    System.out.println("Exiting... Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("[✗ ERROR] Invalid choice. Please try again.");
            }
        }
    }
}
