package dao;

import model.*;
import util.DBConnUtil;
import exception.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SISDAOImpl implements SISDAOInterface {

    @Override
    public void enrollStudentInCourse(String studentId, String courseId, String enrollmentDate)
            throws StudentNotFoundException, CourseNotFoundException, DuplicateEnrollmentException, InvalidEnrollmentDataException {

        if (studentId == null || courseId == null || enrollmentDate == null || enrollmentDate.isEmpty()) {
            throw new InvalidEnrollmentDataException("Enrollment data is incomplete.");
        }

        try (Connection conn = DBConnUtil.getConnection()) {

            // Check if student exists
            PreparedStatement checkStudent = conn.prepareStatement("SELECT * FROM Students WHERE student_id = ?");
            checkStudent.setString(1, studentId);
            ResultSet rs1 = checkStudent.executeQuery();
            if (!rs1.next()) throw new StudentNotFoundException("Student not found with ID: " + studentId);

            // Check if course exists
            PreparedStatement checkCourse = conn.prepareStatement("SELECT * FROM Courses WHERE course_id = ?");
            checkCourse.setString(1, courseId);
            ResultSet rs2 = checkCourse.executeQuery();
            if (!rs2.next()) throw new CourseNotFoundException("Course not found with ID: " + courseId);

            // Check for duplicate
            PreparedStatement checkDuplicate = conn.prepareStatement("SELECT * FROM Enrollments WHERE student_id = ? AND course_id = ?");
            checkDuplicate.setString(1, studentId);
            checkDuplicate.setString(2, courseId);
            ResultSet rs3 = checkDuplicate.executeQuery();
            if (rs3.next()) throw new DuplicateEnrollmentException("Student already enrolled in the course.");

            // Insert into Enrollments
            PreparedStatement insert = conn.prepareStatement(
                    "INSERT INTO Enrollments(student_id, course_id, enrollment_date) VALUES (?, ?, ?)");
            insert.setString(1, studentId);
            insert.setString(2, courseId);
            insert.setDate(3, Date.valueOf(enrollmentDate));
            insert.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Database error during enrollment: " + e.getMessage());
        }
    }

    @Override
    public void assignTeacherToCourse(String courseId, String teacherId)
            throws TeacherNotFoundException, CourseNotFoundException {
        try (Connection conn = DBConnUtil.getConnection()) {

            PreparedStatement checkTeacher = conn.prepareStatement("SELECT * FROM Teacher WHERE teacher_id = ?");
            checkTeacher.setString(1, teacherId);
            ResultSet rs1 = checkTeacher.executeQuery();
            if (!rs1.next()) throw new TeacherNotFoundException("Teacher not found with ID: " + teacherId);

            PreparedStatement checkCourse = conn.prepareStatement("SELECT * FROM Courses WHERE course_id = ?");
            checkCourse.setString(1, courseId);
            ResultSet rs2 = checkCourse.executeQuery();
            if (!rs2.next()) throw new CourseNotFoundException("Course not found with ID: " + courseId);

            PreparedStatement update = conn.prepareStatement("UPDATE Courses SET teacher_id = ? WHERE course_id = ?");
            update.setString(1, teacherId);
            update.setString(2, courseId);
            update.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Database error during course-teacher assignment: " + e.getMessage());
        }
    }

    @Override
    public void recordPayment(String studentId, double amount, String paymentDate)
            throws StudentNotFoundException, PaymentValidationException {
        if (studentId == null || amount <= 0 || paymentDate == null || paymentDate.isEmpty()) {
            throw new PaymentValidationException("Invalid payment details.");
        }

        try (Connection conn = DBConnUtil.getConnection()) {
            PreparedStatement check = conn.prepareStatement("SELECT * FROM Students WHERE student_id = ?");
            check.setString(1, studentId);
            ResultSet rs = check.executeQuery();
            if (!rs.next()) throw new StudentNotFoundException("Student not found for payment.");

            PreparedStatement insert = conn.prepareStatement(
                    "INSERT INTO Payments(student_id, amount, payment_date) VALUES (?, ?, ?)");
            insert.setString(1, studentId);
            insert.setDouble(2, amount);
            insert.setDate(3, Date.valueOf(paymentDate));
            insert.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Error recording payment: " + e.getMessage());
        }
    }

    @Override
    public List<String> getEnrollmentsForStudent(String studentId)
            throws StudentNotFoundException {
        List<String> enrollments = new ArrayList<>();

        try (Connection conn = DBConnUtil.getConnection()) {
            PreparedStatement check = conn.prepareStatement("SELECT * FROM Students WHERE student_id = ?");
            check.setString(1, studentId);
            ResultSet rs1 = check.executeQuery();
            if (!rs1.next()) throw new StudentNotFoundException("Student not found.");

            PreparedStatement stmt = conn.prepareStatement(
                    "SELECT c.course_name, e.enrollment_date FROM Enrollments e JOIN Courses c ON e.course_id = c.course_id WHERE e.student_id = ?");
            stmt.setString(1, studentId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String courseName = rs.getString("course_name");
                String date = rs.getString("enrollment_date");
                enrollments.add(courseName + " on " + date);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving enrollments: " + e.getMessage());
        }

        return enrollments;
    }

    @Override
    public List<String> getCoursesForTeacher(String teacherId)
            throws TeacherNotFoundException {
        List<String> courses = new ArrayList<>();

        try (Connection conn = DBConnUtil.getConnection()) {
            PreparedStatement check = conn.prepareStatement("SELECT * FROM Teacher WHERE teacher_id = ?");
            check.setString(1, teacherId);
            ResultSet rs1 = check.executeQuery();
            if (!rs1.next()) throw new TeacherNotFoundException("Teacher not found.");

            PreparedStatement stmt = conn.prepareStatement("SELECT course_name FROM Courses WHERE teacher_id = ?");
            stmt.setString(1, teacherId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                courses.add(rs.getString("course_name"));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving courses: " + e.getMessage());
        }

        return courses;
    }
}
