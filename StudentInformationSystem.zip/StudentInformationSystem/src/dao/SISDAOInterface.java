package dao;

import model.Student;
import model.Teacher;
import model.Course;

import java.util.List;

import exception.*;

public interface SISDAOInterface {
    void enrollStudentInCourse(String studentId, String courseId, String enrollmentDate)
        throws StudentNotFoundException, CourseNotFoundException, DuplicateEnrollmentException, InvalidEnrollmentDataException;

    void assignTeacherToCourse(String courseId, String teacherId)
        throws TeacherNotFoundException, CourseNotFoundException;

    void recordPayment(String studentId, double amount, String paymentDate)
        throws StudentNotFoundException, PaymentValidationException;

    List<String> getEnrollmentsForStudent(String studentId)
        throws StudentNotFoundException;

    List<String> getCoursesForTeacher(String teacherId)
        throws TeacherNotFoundException;
}
